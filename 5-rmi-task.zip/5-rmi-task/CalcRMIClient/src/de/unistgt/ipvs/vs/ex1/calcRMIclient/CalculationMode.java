package de.unistgt.ipvs.vs.ex1.calcRMIclient;

public enum CalculationMode {
	ADD, SUB, MUL
}
